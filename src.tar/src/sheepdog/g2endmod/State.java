package sheepdog.g2endmod;


public enum State {
	INIT, MANIPULATESHEEP, BRING_SHEEP_IN, PUSH_SHEEP;
}
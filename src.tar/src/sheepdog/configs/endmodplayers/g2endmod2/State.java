package sheepdog.g2endmod2;


public enum State {
	INIT, MANIPULATESHEEP, BRING_SHEEP_IN, PUSH_SHEEP;
}

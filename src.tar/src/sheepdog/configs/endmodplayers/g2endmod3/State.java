package sheepdog.g2endmod3;


public enum State {
	INIT, MANIPULATESHEEP, BRING_SHEEP_IN, PUSH_SHEEP;
}

g2startmod100 sheepdog.g2startmod;


public enum State {
	INIT, MANIPULATESHEEP, BRING_SHEEP_IN, PUSH_SHEEP;
}

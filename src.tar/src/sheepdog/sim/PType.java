package sheepdog.sim;

public enum PType {
    PTYPE_DOG,
    PTYPE_BLACKSHEEP,
    PTYPE_WHITESHEEP
}
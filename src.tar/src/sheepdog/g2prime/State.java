package sheepdog.g2prime;


public enum State {
	INIT, MANIPULATESHEEP, BRING_SHEEP_IN, PUSH_SHEEP;
}
package sheepdog.g9;

public class Global {
    public static int nblacks;
    public static boolean mode;
}
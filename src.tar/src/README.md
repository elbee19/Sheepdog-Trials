sheepdog

Command-line argument:
java sheepdog.sim.Sheepdog arg1 arg2 ....

arg1: group name
arg2: number of dogs
arg3: number of sheeps
arg4: number of black sheeps
arg5: game mode, basic - false, advanced - true
arg6: gui

Example:
Play a game with 5 dogs, 10 sheeps, five of which are black in the basic mode. Display GUI.

java sheepdog.sim.Sheepdog dumb 5 10 5 false true